javac B/B.java
java B.B
