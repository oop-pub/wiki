package B;
import A.A;

class B extends A {
    public void show2() {
        System.out.println("show2B");
    }
   
    public void doStuff() {
        show2();
        super.show2();

        // daca decomentati veti avea eroare la compilare
        //super.show3();
    } 

    public static void main(String[] args) {
        new B().doStuff();
    }
} 

