package A;
public class A {
    private void show1() {
        System.out.println("show1");
    }
    protected void show2() {
        System.out.println("show2A");
    }
    void show3() {
        System.out.println("show3");
    }
}

