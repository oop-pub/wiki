package Linux;

import Bash.*;

public class LinuxOS {

    public static void main(String [] args) {
        Bash tty1 = new Bash();
        tty1.start();
    }
}
