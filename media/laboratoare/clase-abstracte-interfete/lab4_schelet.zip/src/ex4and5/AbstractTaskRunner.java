package ex4and5;

import ex2.Container;
import ex3.Strategy;
import ex1.Task;

public abstract class AbstractTaskRunner {

}
