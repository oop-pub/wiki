package ex1;

import java.util.Random;

public interface Task {
    
	/**
	 * Executes the action characteristic of the task
	 */
	void execute();
 
}




