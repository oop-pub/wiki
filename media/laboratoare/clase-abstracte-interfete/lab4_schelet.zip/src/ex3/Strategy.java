package ex3;

/**
 * Enumerates the types of strategies for the containters.
 * @author marius-andrei
 *
 */
public enum Strategy {
	FIFO, LIFO
}

