HashTester.java trebuie sa fie la acelasi nivel cu sursele voastre, si compilat impreuna cu acestea.
test1.txt trebuie plasat alaturi de fisierele .class.

Rulare: java HashTester

Testele 1-3 (cate 1p) verifica operatiile de baza al tabelei, fara analiza structurii interne a acesteia (bucket-uri etc).
Testul 4 (2p) verifica daca fiecare entry se afla in bucket-ul corespunzator, in functie de hashCode-ul sau.
Testul 5 (3p) citeste din test1.txt o lista de chei si verifica dispunerea exacta a acestora in bucket-uri.

Punctajul maxim acordat de checker este 8 (aferent primei cerinte a temei).

In ceea ce priveste primele 3 teste, asigurati-va ca respectati valorile de retur al metodelor get, put etc.