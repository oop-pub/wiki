
public class ExpressionParser {

	public float eval(String expression) throws SyntacticException, EvaluatorException{
		// do the magic
		
		return 0f;
	}
	
}
