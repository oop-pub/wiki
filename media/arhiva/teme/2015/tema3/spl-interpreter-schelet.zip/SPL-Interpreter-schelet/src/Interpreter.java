

public class Interpreter {
	
	Interpreter() {

	}

	//TODO
	void parse() {}
	
	public static void main(String[] args)  {

	}
}
