package card_game;

public class CommandFactory {

	/**
	*	TODO
	*	
	*	This class behaves as a Singleton, so make the
	*	necessary arrangements
	*/

	public static GameCommand getCommand (Card c, GameAction action ) {
		//TODO return a *concrete* GameCommand instance depending on the values of the arguments
		return null;
	}
}

