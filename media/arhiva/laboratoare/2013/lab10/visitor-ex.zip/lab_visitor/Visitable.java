package lab_visitor;
import java.util.LinkedList;

public interface Visitable {
	public void accept(Visitor v);
}

class Employee implements Visitable{
	protected String  name;
	protected float salary;        
	public Employee(String name, float salary) {
		this.name       = name;
		this.salary     = salary;
	}
	public String getName() {
		return name;
	}
	public float getSalary() {
		return salary;
	} 
	@Override
	public void accept(Visitor v) {
		v.visit(this);  
	}
}

class Boss extends Employee {        
	protected float bonus;
	
	public LinkedList<Visitable> getSubordinates() {
		//TODO
		return null;
	}
	public void addSubordinate(Visitable subordinate) {
		//TODO
	}
	public Boss(String name, float salary, float bonus) {
		super(name, salary);
		this.bonus = bonus;
	}        
	public float getBonus() {
		return bonus;
	}
	public void setBonus(float bonus) {
		this.bonus = bonus;
	}
	
	@Override
	public void accept(Visitor v) {
		v.visit(this);  
	}
}

//TODO
class Intern{
	
	private String  name;
	private int duration;  // in months
	
	public Intern(String name, int duration){
		this.name = name;
		this.duration = duration;
	}
	
	
}
